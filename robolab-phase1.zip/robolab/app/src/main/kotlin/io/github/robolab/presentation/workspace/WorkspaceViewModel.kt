package io.github.robolab.presentation.workspace

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.navigation.toRoute
import dagger.hilt.android.lifecycle.HiltViewModel
import io.github.robolab.core.navigation.Route
import io.github.robolab.domain.model.Project
import io.github.robolab.domain.usecase.ObserveProjectUseCase
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import javax.inject.Inject

@HiltViewModel
class WorkspaceViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    observeProject: ObserveProjectUseCase,
) : ViewModel() {
    private val projectId = savedStateHandle.toRoute<Route.Workspace>().projectId

    val project: StateFlow<Project?> = observeProject(projectId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)
}
