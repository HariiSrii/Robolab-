package io.github.robolab.data.repository

import io.github.robolab.data.local.ProjectDao
import io.github.robolab.data.local.ProjectEntity
import io.github.robolab.domain.model.BoardType
import io.github.robolab.domain.model.Project
import io.github.robolab.domain.repository.ProjectRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject

class ProjectRepositoryImpl @Inject constructor(private val dao: ProjectDao) : ProjectRepository {
    override fun observeAll(): Flow<List<Project>> = dao.observeAll().map { list -> list.map { it.toDomain() } }
    override fun observe(id: String): Flow<Project?> = dao.observe(id).map { it?.toDomain() }
    override suspend fun upsert(project: Project) = dao.upsert(project.toEntity())
    override suspend fun rename(id: String, name: String, now: Long) = dao.rename(id, name, now)
    override suspend fun delete(id: String) = dao.delete(id)
}

private fun ProjectEntity.toDomain() = Project(
    id, name, BoardType.fromName(board), circuitJson, sketchSource, createdAt, updatedAt,
)

private fun Project.toEntity() = ProjectEntity(
    id, name, board.name, circuitJson, sketchSource, createdAt, updatedAt,
)
