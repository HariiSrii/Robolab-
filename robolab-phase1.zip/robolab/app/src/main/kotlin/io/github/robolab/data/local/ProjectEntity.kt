package io.github.robolab.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey val id: String,
    val name: String,
    val board: String,
    val circuitJson: String,
    val sketchSource: String,
    val createdAt: Long,
    val updatedAt: Long,
)
