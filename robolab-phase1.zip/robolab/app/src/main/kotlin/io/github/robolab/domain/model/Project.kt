package io.github.robolab.domain.model

/** Pure Kotlin domain model: no Android or Room types. */
data class Project(
    val id: String,
    val name: String,
    val board: BoardType,
    /** Serialized circuit schema (JSON); schema is defined in Phase 2/3. */
    val circuitJson: String,
    val sketchSource: String,
    val createdAt: Long,
    val updatedAt: Long,
)

object SketchTemplates {
    val BLINK = """void setup() {
  pinMode(LED_BUILTIN, OUTPUT);
}

void loop() {
  digitalWrite(LED_BUILTIN, HIGH);
  delay(1000);
  digitalWrite(LED_BUILTIN, LOW);
  delay(1000);
}
""".trimIndent()
}
