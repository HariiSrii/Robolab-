package io.github.robolab.core.di

import android.content.Context
import androidx.room.Room
import dagger.Binds
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import io.github.robolab.data.local.ProjectDao
import io.github.robolab.data.local.RoboLabDatabase
import io.github.robolab.data.repository.ProjectRepositoryImpl
import io.github.robolab.domain.repository.ProjectRepository
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {
    @Provides @Singleton
    fun database(@ApplicationContext ctx: Context): RoboLabDatabase =
        Room.databaseBuilder(ctx, RoboLabDatabase::class.java, "robolab.db").build()

    @Provides
    fun projectDao(db: RoboLabDatabase): ProjectDao = db.projectDao()
}

@Module
@InstallIn(SingletonComponent::class)
abstract class RepositoryModule {
    @Binds @Singleton
    abstract fun projects(impl: ProjectRepositoryImpl): ProjectRepository
}
