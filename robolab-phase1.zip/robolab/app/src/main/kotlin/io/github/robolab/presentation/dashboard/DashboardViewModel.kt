package io.github.robolab.presentation.dashboard

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import io.github.robolab.domain.model.BoardType
import io.github.robolab.domain.model.Project
import io.github.robolab.domain.usecase.CreateProjectUseCase
import io.github.robolab.domain.usecase.DeleteProjectUseCase
import io.github.robolab.domain.usecase.ObserveProjectsUseCase
import io.github.robolab.domain.usecase.RenameProjectUseCase
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

data class DashboardUiState(
    val projects: List<Project> = emptyList(),
    val isLoading: Boolean = true,
)

@HiltViewModel
class DashboardViewModel @Inject constructor(
    observeProjects: ObserveProjectsUseCase,
    private val createProject: CreateProjectUseCase,
    private val renameProject: RenameProjectUseCase,
    private val deleteProject: DeleteProjectUseCase,
) : ViewModel() {

    val uiState: StateFlow<DashboardUiState> = observeProjects()
        .map { DashboardUiState(projects = it, isLoading = false) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), DashboardUiState())

    fun create(name: String, board: BoardType, onCreated: (String) -> Unit) {
        viewModelScope.launch { onCreated(createProject(name, board)) }
    }

    fun rename(id: String, name: String) {
        viewModelScope.launch { renameProject(id, name) }
    }

    fun delete(id: String) {
        viewModelScope.launch { deleteProject(id) }
    }
}
