package io.github.robolab.domain.usecase

import io.github.robolab.domain.model.BoardType
import io.github.robolab.domain.model.Project
import io.github.robolab.domain.model.SketchTemplates
import io.github.robolab.domain.repository.ProjectRepository
import kotlinx.coroutines.flow.Flow
import java.util.UUID
import javax.inject.Inject

class ObserveProjectsUseCase @Inject constructor(private val repo: ProjectRepository) {
    operator fun invoke(): Flow<List<Project>> = repo.observeAll()
}

class ObserveProjectUseCase @Inject constructor(private val repo: ProjectRepository) {
    operator fun invoke(id: String): Flow<Project?> = repo.observe(id)
}

class CreateProjectUseCase @Inject constructor(private val repo: ProjectRepository) {
    /** Returns the new project's id. */
    suspend operator fun invoke(name: String, board: BoardType): String {
        val now = System.currentTimeMillis()
        val project = Project(
            id = UUID.randomUUID().toString(),
            name = name.trim().ifEmpty { "Untitled project" },
            board = board,
            circuitJson = "{}",
            sketchSource = SketchTemplates.BLINK,
            createdAt = now,
            updatedAt = now,
        )
        repo.upsert(project)
        return project.id
    }
}

class RenameProjectUseCase @Inject constructor(private val repo: ProjectRepository) {
    suspend operator fun invoke(id: String, name: String) {
        val clean = name.trim()
        if (clean.isNotEmpty()) repo.rename(id, clean, System.currentTimeMillis())
    }
}

class DeleteProjectUseCase @Inject constructor(private val repo: ProjectRepository) {
    suspend operator fun invoke(id: String) = repo.delete(id)
}
