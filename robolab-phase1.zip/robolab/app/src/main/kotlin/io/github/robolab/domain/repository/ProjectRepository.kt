package io.github.robolab.domain.repository

import io.github.robolab.domain.model.Project
import kotlinx.coroutines.flow.Flow

interface ProjectRepository {
    fun observeAll(): Flow<List<Project>>
    fun observe(id: String): Flow<Project?>
    suspend fun upsert(project: Project)
    suspend fun rename(id: String, name: String, now: Long)
    suspend fun delete(id: String)
}
