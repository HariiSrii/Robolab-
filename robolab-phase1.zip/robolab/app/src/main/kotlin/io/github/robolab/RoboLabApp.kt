package io.github.robolab

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class RoboLabApp : Application()
