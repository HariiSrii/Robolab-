package io.github.robolab.core.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import io.github.robolab.presentation.dashboard.DashboardScreen
import io.github.robolab.presentation.workspace.WorkspaceScreen
import kotlinx.serialization.Serializable

sealed interface Route {
    @Serializable data object Dashboard : Route
    @Serializable data class Workspace(val projectId: String) : Route
}

@Composable
fun AppNavHost() {
    val nav = rememberNavController()
    NavHost(navController = nav, startDestination = Route.Dashboard) {
        composable<Route.Dashboard> {
            DashboardScreen(onOpenProject = { nav.navigate(Route.Workspace(it)) })
        }
        composable<Route.Workspace> {
            WorkspaceScreen(onBack = { nav.popBackStack() })
        }
    }
}
