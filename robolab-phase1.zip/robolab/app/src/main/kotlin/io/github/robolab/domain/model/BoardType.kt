package io.github.robolab.domain.model

enum class BoardType(
    val displayName: String,
    val mcu: String,
    val flashKb: Int,
    val sramKb: Int,
    val digitalPins: Int,
    val analogPins: Int,
) {
    UNO("Arduino Uno", "ATmega328P", 32, 2, 14, 6),
    NANO("Arduino Nano", "ATmega328P", 32, 2, 14, 8),
    MEGA("Arduino Mega 2560", "ATmega2560", 256, 8, 54, 16);

    companion object {
        fun fromName(name: String): BoardType = entries.firstOrNull { it.name == name } ?: UNO
    }
}
